<?php
class JWT {
    private static function secret(): string {
        return getenv('JWT_SECRET') ?: 'mamatradr_secret_change_in_prod_2024';
    }

    public static function encode(array $payload): string {
        $header  = self::b64(json_encode(['alg'=>'HS256','typ'=>'JWT']));
        $payload['iat'] = time();
        $payload['exp'] = time() + 86400 * 7; // 7 days
        $body    = self::b64(json_encode($payload));
        $sig     = self::b64(hash_hmac('sha256', "$header.$body", self::secret(), true));
        return "$header.$body.$sig";
    }

    public static function decode(string $token): ?array {
        $parts = explode('.', $token);
        if (count($parts) !== 3) return null;
        [$header, $body, $sig] = $parts;
        $expected = self::b64(hash_hmac('sha256', "$header.$body", self::secret(), true));
        if (!hash_equals($expected, $sig)) return null;
        $payload = json_decode(self::b64decode($body), true);
        if (!$payload || $payload['exp'] < time()) return null;
        return $payload;
    }

    private static function b64(string $data): string {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }

    private static function b64decode(string $data): string {
        return base64_decode(strtr($data, '-_', '+/'));
    }
}
