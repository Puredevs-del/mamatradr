<?php
class Response {
    public static function json(bool $success, string $message = 'OK', $data = null, int $status = 200): void {
        http_response_code($status);
        header('Content-Type: application/json');
        echo json_encode(compact('success', 'message', 'data'), JSON_UNESCAPED_UNICODE);
        exit;
    }

    public static function ok($data = null, string $msg = 'OK'): void {
        self::json(true, $msg, $data);
    }

    public static function error(string $msg, int $status = 400): void {
        self::json(false, $msg, null, $status);
    }

    public static function unauthorized(): void {
        self::error('Unauthorized', 401);
    }

    public static function notFound(string $msg = 'Not found'): void {
        self::error($msg, 404);
    }
}
