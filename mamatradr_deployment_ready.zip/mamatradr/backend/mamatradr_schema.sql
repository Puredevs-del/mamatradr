-- MamaTradr MVP Database Schema
-- Import into phpMyAdmin: select mamatradr db → Import → choose this file → Go

SET FOREIGN_KEY_CHECKS = 0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";

-- ─── Sellers ──────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `sellers` (
  `id`            INT UNSIGNED     NOT NULL AUTO_INCREMENT,
  `name`          VARCHAR(120)     NOT NULL,
  `email`         VARCHAR(180)     NOT NULL,
  `phone`         VARCHAR(20)      NOT NULL,
  `password_hash` VARCHAR(255)     NOT NULL,
  `created_at`    TIMESTAMP        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sellers_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─── Customers ────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `customers` (
  `id`            INT UNSIGNED     NOT NULL AUTO_INCREMENT,
  `name`          VARCHAR(120)     NOT NULL,
  `email`         VARCHAR(180)     NOT NULL,
  `phone`         VARCHAR(20)      NOT NULL,
  `password_hash` VARCHAR(255)     NOT NULL,
  `created_at`    TIMESTAMP        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `customers_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─── Admins ───────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `admins` (
  `id`        INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `username`  VARCHAR(60)  NOT NULL DEFAULT 'admin',
  `pin_hash`  VARCHAR(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `admins_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Default admin row (PIN = 1234, change via fix_admin_pin.php or update directly)
INSERT IGNORE INTO `admins` (`username`, `pin_hash`)
VALUES ('admin', '$2y$10$placeholder_run_fix_admin_pin_php');

-- ─── Shops ────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `shops` (
  `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `seller_id`   INT UNSIGNED NOT NULL,
  `name`        VARCHAR(160) NOT NULL,
  `description` TEXT,
  `category`    VARCHAR(80)  NOT NULL,
  `location`    VARCHAR(120) DEFAULT '',
  `verified`    TINYINT(1)   NOT NULL DEFAULT 0,
  `created_at`  TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `shops_seller` (`seller_id`),
  KEY `shops_verified` (`verified`),
  CONSTRAINT `fk_shops_seller` FOREIGN KEY (`seller_id`) REFERENCES `sellers`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─── Listings ─────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `listings` (
  `id`          INT UNSIGNED   NOT NULL AUTO_INCREMENT,
  `shop_id`     INT UNSIGNED   NOT NULL,
  `title`       VARCHAR(200)   NOT NULL,
  `description` TEXT,
  `price`       DECIMAL(12,2)  NOT NULL,
  `stock`       INT            NOT NULL DEFAULT 0,
  `unit`        VARCHAR(40)    NOT NULL DEFAULT 'item',
  `available`   TINYINT(1)     NOT NULL DEFAULT 1,
  `created_at`  TIMESTAMP      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `listings_shop` (`shop_id`),
  KEY `listings_available` (`available`),
  CONSTRAINT `fk_listings_shop` FOREIGN KEY (`shop_id`) REFERENCES `shops`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─── Orders ───────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `orders` (
  `id`           INT UNSIGNED   NOT NULL AUTO_INCREMENT,
  `customer_id`  INT UNSIGNED   NOT NULL,
  `total_amount` DECIMAL(14,2)  NOT NULL,
  `status`       ENUM('pending','confirmed','shipped','delivered','completed','cancelled')
                               NOT NULL DEFAULT 'pending',
  `notes`        TEXT,
  `created_at`   TIMESTAMP      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `orders_customer` (`customer_id`),
  KEY `orders_status` (`status`),
  CONSTRAINT `fk_orders_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─── Order Items ──────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `order_items` (
  `id`         INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `order_id`   INT UNSIGNED  NOT NULL,
  `listing_id` INT UNSIGNED  NOT NULL,
  `qty`        INT           NOT NULL DEFAULT 1,
  `unit_price` DECIMAL(12,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `oi_order` (`order_id`),
  KEY `oi_listing` (`listing_id`),
  CONSTRAINT `fk_oi_order`   FOREIGN KEY (`order_id`)   REFERENCES `orders`(`id`)   ON DELETE CASCADE,
  CONSTRAINT `fk_oi_listing` FOREIGN KEY (`listing_id`) REFERENCES `listings`(`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─── Transactions (Escrow) ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `transactions` (
  `id`         INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `order_id`   INT UNSIGNED  NOT NULL,
  `amount`     DECIMAL(14,2) NOT NULL,
  `status`     ENUM('held','released','refunded') NOT NULL DEFAULT 'held',
  `created_at` TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `tx_order` (`order_id`),
  CONSTRAINT `fk_tx_order` FOREIGN KEY (`order_id`) REFERENCES `orders`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET FOREIGN_KEY_CHECKS = 1;
