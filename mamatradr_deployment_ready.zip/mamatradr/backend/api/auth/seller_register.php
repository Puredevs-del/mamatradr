<?php
require_once __DIR__ . '/../../bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') Response::error('Method not allowed', 405);

$b = $GLOBALS['body'];
$name  = trim($b['name'] ?? '');
$email = strtolower(trim($b['email'] ?? ''));
$phone = trim($b['phone'] ?? '');
$pass  = $b['password'] ?? '';

if (!$name || !$email || !$phone || !$pass) Response::error('All fields required');
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) Response::error('Invalid email');
if (strlen($pass) < 6) Response::error('Password must be at least 6 characters');

$db = getDB();
$existing = $db->prepare('SELECT id FROM sellers WHERE email = ?');
$existing->execute([$email]);
if ($existing->fetch()) Response::error('Email already registered');

$hash = password_hash($pass, PASSWORD_DEFAULT);
$stmt = $db->prepare('INSERT INTO sellers (name, email, phone, password_hash) VALUES (?,?,?,?)');
$stmt->execute([$name, $email, $phone, $hash]);
$id = $db->lastInsertId();

$token = JWT::encode(['id' => $id, 'role' => 'seller', 'name' => $name, 'email' => $email]);
Response::ok(['token' => $token, 'seller' => ['id'=>$id,'name'=>$name,'email'=>$email,'phone'=>$phone]], 'Registered successfully');
