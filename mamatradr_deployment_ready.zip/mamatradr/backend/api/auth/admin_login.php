<?php
require_once __DIR__ . '/../../bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') Response::error('Method not allowed', 405);

$b   = $GLOBALS['body'];
$pin = $b['pin'] ?? '';

if (!$pin) Response::error('PIN required');

$db   = getDB();
$stmt = $db->prepare('SELECT * FROM admins WHERE username = ?');
$stmt->execute(['admin']);
$admin = $stmt->fetch();

if (!$admin || !password_verify($pin, $admin['pin_hash'])) {
    Response::error('Invalid PIN', 401);
}

$token = JWT::encode(['id' => $admin['id'], 'role' => 'admin', 'name' => 'Admin']);
Response::ok(['token' => $token]);
