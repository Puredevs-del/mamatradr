<?php
require_once __DIR__ . '/../../bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') Response::error('Method not allowed', 405);

$b     = $GLOBALS['body'];
$email = strtolower(trim($b['email'] ?? ''));
$pass  = $b['password'] ?? '';

if (!$email || !$pass) Response::error('Email and password required');

$db   = getDB();
$stmt = $db->prepare('SELECT * FROM customers WHERE email = ?');
$stmt->execute([$email]);
$customer = $stmt->fetch();

if (!$customer || !password_verify($pass, $customer['password_hash'])) {
    Response::error('Invalid credentials', 401);
}

$token = JWT::encode(['id' => $customer['id'], 'role' => 'customer', 'name' => $customer['name'], 'email' => $customer['email']]);
unset($customer['password_hash']);
Response::ok(['token' => $token, 'customer' => $customer]);
