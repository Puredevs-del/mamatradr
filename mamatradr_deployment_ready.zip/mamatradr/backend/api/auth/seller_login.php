<?php
require_once __DIR__ . '/../../bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') Response::error('Method not allowed', 405);

$b     = $GLOBALS['body'];
$email = strtolower(trim($b['email'] ?? ''));
$pass  = $b['password'] ?? '';

if (!$email || !$pass) Response::error('Email and password required');

$db   = getDB();
$stmt = $db->prepare('SELECT * FROM sellers WHERE email = ?');
$stmt->execute([$email]);
$seller = $stmt->fetch();

if (!$seller || !password_verify($pass, $seller['password_hash'])) {
    Response::error('Invalid credentials', 401);
}

$token = JWT::encode(['id' => $seller['id'], 'role' => 'seller', 'name' => $seller['name'], 'email' => $seller['email']]);
unset($seller['password_hash']);
Response::ok(['token' => $token, 'seller' => $seller]);
