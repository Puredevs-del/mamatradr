<?php
require_once __DIR__ . '/../../bootstrap.php';
requireAuth('admin');

$db   = getDB();
$stmt = $db->query('SELECT s.*, sel.name as seller_name, sel.email as seller_email, COUNT(l.id) as listing_count FROM shops s JOIN sellers sel ON sel.id = s.seller_id LEFT JOIN listings l ON l.shop_id = s.id GROUP BY s.id ORDER BY s.verified ASC, s.created_at DESC');
Response::ok($stmt->fetchAll());
