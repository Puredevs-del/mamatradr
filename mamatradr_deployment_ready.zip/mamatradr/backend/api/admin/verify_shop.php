<?php
require_once __DIR__ . '/../../bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') Response::error('Method not allowed', 405);
requireAuth('admin');

$shopId = intval($GLOBALS['body']['shop_id'] ?? 0);
if (!$shopId) Response::error('shop_id required');

$db = getDB();
$db->prepare('UPDATE shops SET verified = 1 WHERE id = ?')->execute([$shopId]);
Response::ok(['shop_id' => $shopId, 'verified' => true]);
