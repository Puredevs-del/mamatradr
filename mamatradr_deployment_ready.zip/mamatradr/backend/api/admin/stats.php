<?php
require_once __DIR__ . '/../../bootstrap.php';
requireAuth('admin');

$db = getDB();

$stats = [
    'sellers'          => $db->query('SELECT COUNT(*) FROM sellers')->fetchColumn(),
    'customers'        => $db->query('SELECT COUNT(*) FROM customers')->fetchColumn(),
    'shops_total'      => $db->query('SELECT COUNT(*) FROM shops')->fetchColumn(),
    'shops_pending'    => $db->query('SELECT COUNT(*) FROM shops WHERE verified = 0')->fetchColumn(),
    'shops_verified'   => $db->query('SELECT COUNT(*) FROM shops WHERE verified = 1')->fetchColumn(),
    'listings'         => $db->query('SELECT COUNT(*) FROM listings')->fetchColumn(),
    'orders_total'     => $db->query('SELECT COUNT(*) FROM orders')->fetchColumn(),
    'orders_pending'   => $db->query('SELECT COUNT(*) FROM orders WHERE status = "pending"')->fetchColumn(),
    'revenue_held'     => $db->query('SELECT COALESCE(SUM(amount),0) FROM transactions WHERE status = "held"')->fetchColumn(),
    'revenue_released' => $db->query('SELECT COALESCE(SUM(amount),0) FROM transactions WHERE status = "released"')->fetchColumn(),
];

Response::ok($stats);
