<?php
require_once __DIR__ . '/../../bootstrap.php';

$shopId = intval($_GET['shop_id'] ?? 0);
if (!$shopId) Response::error('shop_id required');

$db   = getDB();
$stmt = $db->prepare('SELECT * FROM listings WHERE shop_id = ? ORDER BY created_at DESC');
$stmt->execute([$shopId]);
Response::ok($stmt->fetchAll());
