<?php
require_once __DIR__ . '/../../bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') Response::error('Method not allowed', 405);
$auth = requireAuth('seller');

$listingId = intval($GLOBALS['body']['listing_id'] ?? 0);
if (!$listingId) Response::error('listing_id required');

$db = getDB();

// Confirm ownership
$stmt = $db->prepare('SELECT l.* FROM listings l JOIN shops s ON s.id = l.shop_id WHERE l.id = ? AND s.seller_id = ?');
$stmt->execute([$listingId, $auth['id']]);
$listing = $stmt->fetch();
if (!$listing) Response::notFound('Listing not found or not yours');

$newStatus = $listing['available'] ? 0 : 1;
$db->prepare('UPDATE listings SET available = ? WHERE id = ?')->execute([$newStatus, $listingId]);
Response::ok(['available' => $newStatus]);
