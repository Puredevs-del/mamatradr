<?php
require_once __DIR__ . '/../../bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') Response::error('Method not allowed', 405);
$auth = requireAuth('seller');

$b     = $GLOBALS['body'];
$title = trim($b['title'] ?? '');
$desc  = trim($b['description'] ?? '');
$price = floatval($b['price'] ?? 0);
$stock = intval($b['stock'] ?? 0);
$unit  = trim($b['unit'] ?? 'item');

if (!$title || !$price) Response::error('Title and price are required');

$db = getDB();
$shopStmt = $db->prepare('SELECT id FROM shops WHERE seller_id = ?');
$shopStmt->execute([$auth['id']]);
$shop = $shopStmt->fetch();
if (!$shop) Response::error('Create a shop first');

$stmt = $db->prepare('INSERT INTO listings (shop_id, title, description, price, stock, unit, available) VALUES (?,?,?,?,?,?,1)');
$stmt->execute([$shop['id'], $title, $desc, $price, $stock, $unit]);
$id = $db->lastInsertId();

Response::ok(['id'=>$id,'shop_id'=>$shop['id'],'title'=>$title,'description'=>$desc,'price'=>$price,'stock'=>$stock,'unit'=>$unit,'available'=>1], 'Listing created');
