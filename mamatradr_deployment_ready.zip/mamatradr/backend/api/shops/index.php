<?php
require_once __DIR__ . '/../../bootstrap.php';

$db   = getDB();
$stmt = $db->query('SELECT s.*, COUNT(l.id) as listing_count FROM shops s LEFT JOIN listings l ON l.shop_id = s.id WHERE s.verified = 1 GROUP BY s.id ORDER BY s.created_at DESC');
Response::ok($stmt->fetchAll());
