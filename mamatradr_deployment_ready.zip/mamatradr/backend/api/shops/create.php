<?php
require_once __DIR__ . '/../../bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') Response::error('Method not allowed', 405);
$auth = requireAuth('seller');

$b    = $GLOBALS['body'];
$name = trim($b['name'] ?? '');
$desc = trim($b['description'] ?? '');
$cat  = trim($b['category'] ?? '');
$loc  = trim($b['location'] ?? '');

if (!$name || !$desc || !$cat) Response::error('Name, description and category are required');

$db = getDB();

// Check if seller already has a shop
$existing = $db->prepare('SELECT id FROM shops WHERE seller_id = ?');
$existing->execute([$auth['id']]);
if ($existing->fetch()) Response::error('You already have a shop');

$stmt = $db->prepare('INSERT INTO shops (seller_id, name, description, category, location, verified) VALUES (?,?,?,?,?,0)');
$stmt->execute([$auth['id'], $name, $desc, $cat, $loc]);
$id = $db->lastInsertId();

Response::ok(['id' => $id, 'name' => $name, 'description' => $desc, 'category' => $cat, 'location' => $loc, 'verified' => 0], 'Shop created. Awaiting admin verification.');
