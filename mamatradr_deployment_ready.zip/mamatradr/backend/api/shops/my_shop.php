<?php
require_once __DIR__ . '/../../bootstrap.php';
$auth = requireAuth('seller');

$db   = getDB();
$stmt = $db->prepare('SELECT s.*, COUNT(l.id) as listing_count FROM shops s LEFT JOIN listings l ON l.shop_id = s.id WHERE s.seller_id = ? GROUP BY s.id');
$stmt->execute([$auth['id']]);
$shop = $stmt->fetch();

if (!$shop) Response::notFound('No shop found. Create one first.');
Response::ok($shop);
