<?php
require_once __DIR__ . '/../../bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') Response::error('Method not allowed', 405);

$authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
$token      = str_replace('Bearer ', '', $authHeader);
$auth       = JWT::decode($token);
if (!$auth) Response::unauthorized();

$orderId = intval($GLOBALS['body']['order_id'] ?? 0);
if (!$orderId) Response::error('order_id required');

$db   = getDB();
$stmt = $db->prepare('SELECT * FROM orders WHERE id = ?');
$stmt->execute([$orderId]);
$order = $stmt->fetch();
if (!$order) Response::notFound('Order not found');

$flow = ['pending' => 'confirmed', 'confirmed' => 'shipped', 'shipped' => 'delivered', 'delivered' => 'completed'];
$current = $order['status'];
if (!isset($flow[$current])) Response::error("Order is already $current");

$next = $flow[$current];
$db->prepare('UPDATE orders SET status = ? WHERE id = ?')->execute([$next, $orderId]);

// Release escrow when completed
if ($next === 'completed') {
    $db->prepare('UPDATE transactions SET status = ? WHERE order_id = ?')->execute(['released', $orderId]);
}

Response::ok(['order_id' => $orderId, 'status' => $next]);
