<?php
require_once __DIR__ . '/../../bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') Response::error('Method not allowed', 405);
$auth = requireAuth('customer');

$b     = $GLOBALS['body'];
$items = $b['items'] ?? []; // [{listing_id, qty}]
$notes = trim($b['notes'] ?? '');

if (empty($items)) Response::error('Cart is empty');

$db = getDB();
$total = 0;
$orderItems = [];

foreach ($items as $item) {
    $lid = intval($item['listing_id'] ?? 0);
    $qty = intval($item['qty'] ?? 1);
    if (!$lid || $qty < 1) Response::error('Invalid cart item');

    $stmt = $db->prepare('SELECT l.*, s.seller_id FROM listings l JOIN shops s ON s.id = l.shop_id WHERE l.id = ? AND l.available = 1');
    $stmt->execute([$lid]);
    $listing = $stmt->fetch();
    if (!$listing) Response::error("Listing #$lid not available");

    $subtotal = $listing['price'] * $qty;
    $total   += $subtotal;
    $orderItems[] = ['listing' => $listing, 'qty' => $qty, 'subtotal' => $subtotal];
}

// Create order
$orderStmt = $db->prepare('INSERT INTO orders (customer_id, total_amount, status, notes) VALUES (?,?,\'pending\',?)');
$orderStmt->execute([$auth['id'], $total, $notes]);
$orderId = $db->lastInsertId();

// Insert order items
foreach ($orderItems as $oi) {
    $db->prepare('INSERT INTO order_items (order_id, listing_id, qty, unit_price) VALUES (?,?,?,?)')
       ->execute([$orderId, $oi['listing']['id'], $oi['qty'], $oi['listing']['price']]);
}

// Create escrow transaction record
$db->prepare('INSERT INTO transactions (order_id, amount, status) VALUES (?,?,\'held\')')
   ->execute([$orderId, $total]);

Response::ok(['order_id' => $orderId, 'total' => $total, 'status' => 'pending'], 'Order placed. Funds held in escrow.');
