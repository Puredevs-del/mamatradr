<?php
require_once __DIR__ . '/../../bootstrap.php';

$authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
$token      = str_replace('Bearer ', '', $authHeader);
$auth       = JWT::decode($token);
if (!$auth) Response::unauthorized();

$db = getDB();

if ($auth['role'] === 'customer') {
    $stmt = $db->prepare('
        SELECT o.*, 
               GROUP_CONCAT(l.title SEPARATOR ", ") as items_summary
        FROM orders o
        JOIN order_items oi ON oi.order_id = o.id
        JOIN listings l ON l.id = oi.listing_id
        WHERE o.customer_id = ?
        GROUP BY o.id
        ORDER BY o.created_at DESC
    ');
    $stmt->execute([$auth['id']]);
} elseif ($auth['role'] === 'seller') {
    $stmt = $db->prepare('
        SELECT o.*,
               GROUP_CONCAT(l.title SEPARATOR ", ") as items_summary
        FROM orders o
        JOIN order_items oi ON oi.order_id = o.id
        JOIN listings l ON l.id = oi.listing_id
        JOIN shops s ON s.id = l.shop_id
        WHERE s.seller_id = ?
        GROUP BY o.id
        ORDER BY o.created_at DESC
    ');
    $stmt->execute([$auth['id']]);
} elseif ($auth['role'] === 'admin') {
    $stmt = $db->query('
        SELECT o.*,
               GROUP_CONCAT(l.title SEPARATOR ", ") as items_summary,
               c.name as customer_name
        FROM orders o
        JOIN order_items oi ON oi.order_id = o.id
        JOIN listings l ON l.id = oi.listing_id
        JOIN customers c ON c.id = o.customer_id
        GROUP BY o.id
        ORDER BY o.created_at DESC
    ');
} else {
    Response::unauthorized();
}

Response::ok($stmt->fetchAll());
