<?php
// fix_admin_pin.php — Run ONCE in browser to set admin PIN to 1234
// Then DELETE this file immediately.
require_once __DIR__ . '/bootstrap.php';

$pin  = '1234'; // Change this to your preferred PIN before running
$hash = password_hash($pin, PASSWORD_DEFAULT);

$db = getDB();
$db->prepare('UPDATE admins SET pin_hash = ? WHERE username = ?')->execute([$hash, 'admin']);

if ($db->rowCount() === 0) {
    $db->prepare('INSERT INTO admins (username, pin_hash) VALUES (?,?)')->execute(['admin', $hash]);
}

echo '<h2 style="font-family:sans-serif;color:green">✅ Done. Admin PIN set to: ' . htmlspecialchars($pin) . '</h2>';
echo '<p style="font-family:sans-serif;color:red"><strong>DELETE this file now.</strong> It is a security risk to leave it accessible.</p>';
