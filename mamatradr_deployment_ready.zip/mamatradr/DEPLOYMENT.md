# MamaTradr MVP — Deployment Guide

## What's in this package

```
mamatradr/
├── backend/
│   ├── api/
│   │   ├── auth/          seller_register, seller_login, customer_register, customer_login, admin_login
│   │   ├── shops/         index (list), create, my_shop
│   │   ├── listings/      index (by shop), create, toggle
│   │   ├── orders/        index, place, advance
│   │   └── admin/         stats, shops, verify_shop
│   ├── config/
│   │   └── database.php
│   ├── helpers/
│   │   ├── JWT.php
│   │   └── Response.php
│   ├── bootstrap.php
│   ├── fix_admin_pin.php  ← DELETE after first run
│   ├── mamatradr_schema.sql
│   ├── .env.example       ← rename to .env
│   └── apiService.js      ← copy to React src/
└── frontend/src/
    └── MamaTradr_MVP.jsx
```

---

## Local Setup (XAMPP)

### Step 1 — Place backend files
Extract into: `C:\xampp\htdocs\MAMATRADR\backend\`

Final structure should be:
```
C:\xampp\htdocs\MAMATRADR\backend\bootstrap.php
C:\xampp\htdocs\MAMATRADR\backend\api\auth\seller_login.php
...etc
```

### Step 2 — Configure .env
Copy `.env.example` → `.env` (same folder, remove `.example`).
Leave `DB_PASS=` blank for standard XAMPP.

### Step 3 — Import database
- Open phpMyAdmin: http://localhost/phpmyadmin
- Select the `mamatradr` database
- Click Import → choose `mamatradr_schema.sql` → Go

### Step 4 — Set admin PIN
Visit: http://localhost/MAMATRADR/backend/fix_admin_pin.php
You'll see "Done. Admin PIN set to: 1234"
**Delete this file immediately after.**

### Step 5 — Smoke test
Visit: http://localhost/MAMATRADR/backend/api/shops/index.php
You should see: `{"success":true,"message":"OK","data":[]}`

### Step 6 — React frontend
1. Copy `apiService.js` into your React project's `src/` folder
2. Copy `MamaTradr_MVP.jsx` into `src/` (rename to `App.jsx` or import as needed)
3. Make sure `App.jsx` imports from `./apiService`
4. Run: `npm start`

The `REACT_APP_API_URL` defaults to `http://localhost/MAMATRADR/backend/api`.
To change it, add to your `.env` in the React project root:
```
REACT_APP_API_URL=http://localhost/MAMATRADR/backend/api
```

---

## Production Deployment

### Backend (PHP)
1. Upload `backend/` to your server (e.g. `/var/www/html/mamatradr/backend/`)
2. Set `.env` values — especially `JWT_SECRET` (use a long random string) and `ALLOWED_ORIGIN` (your frontend domain)
3. Ensure PHP 7.4+ and MySQL/MariaDB are available
4. Import `mamatradr_schema.sql` via phpMyAdmin or `mysql -u root -p mamatradr < mamatradr_schema.sql`
5. Run `fix_admin_pin.php` once then delete it

### Frontend (React)
1. Set `REACT_APP_API_URL=https://yourdomain.com/mamatradr/backend/api` in `.env`
2. Run `npm run build`
3. Upload the `build/` folder to your hosting (Netlify, Vercel, or Apache/Nginx public folder)

---

## User Flows

| Who | Can do |
|-----|--------|
| **Customer** | Register → Browse verified shops → Add to cart → Checkout (escrow) → Track orders |
| **Seller** | Register → Create shop → Add listings → Toggle availability → Advance order status |
| **Admin** | PIN login → View platform stats → Verify shops → Advance any order |

## Order Status Flow
`pending` → `confirmed` → `shipped` → `delivered` → `completed`
Escrow funds release automatically when order reaches `completed`.

## Default Admin PIN
`1234` — change in `fix_admin_pin.php` before running, or update via phpMyAdmin:
```sql
UPDATE admins SET pin_hash = '$2y$10$...' WHERE username = 'admin';
```

---

## API Endpoints Summary

| Endpoint | Method | Auth |
|----------|--------|------|
| `/auth/seller_register.php` | POST | None |
| `/auth/seller_login.php` | POST | None |
| `/auth/customer_register.php` | POST | None |
| `/auth/customer_login.php` | POST | None |
| `/auth/admin_login.php` | POST | None |
| `/shops/index.php` | GET | None |
| `/shops/create.php` | POST | Seller JWT |
| `/shops/my_shop.php` | GET | Seller JWT |
| `/listings/index.php?shop_id=N` | GET | None |
| `/listings/create.php` | POST | Seller JWT |
| `/listings/toggle.php` | POST | Seller JWT |
| `/orders/place.php` | POST | Customer JWT |
| `/orders/index.php` | GET | Any JWT |
| `/orders/advance.php` | POST | Seller/Admin JWT |
| `/admin/stats.php` | GET | Admin JWT |
| `/admin/shops.php` | GET | Admin JWT |
| `/admin/verify_shop.php` | POST | Admin JWT |
