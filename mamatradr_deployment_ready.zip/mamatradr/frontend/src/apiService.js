// apiService.js — place in src/
const BASE = process.env.REACT_APP_API_URL || 'http://localhost/MAMATRADR/backend/api';

const getToken = () => localStorage.getItem('mt_token');

async function request(path, options = {}) {
  const token = getToken();
  const res = await fetch(`${BASE}${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(options.headers || {}),
    },
    body: options.body ? JSON.stringify(options.body) : undefined,
  });
  const data = await res.json();
  if (!data.success) throw new Error(data.message || 'Request failed');
  return data.data;
}

export const api = {
  // Auth
  sellerRegister:   (body) => request('/auth/seller_register.php',  { method: 'POST', body }),
  sellerLogin:      (body) => request('/auth/seller_login.php',     { method: 'POST', body }),
  customerRegister: (body) => request('/auth/customer_register.php',{ method: 'POST', body }),
  customerLogin:    (body) => request('/auth/customer_login.php',   { method: 'POST', body }),
  adminLogin:       (body) => request('/auth/admin_login.php',      { method: 'POST', body }),

  // Shops
  getShops:    ()     => request('/shops/index.php'),
  createShop:  (body) => request('/shops/create.php',   { method: 'POST', body }),
  myShop:      ()     => request('/shops/my_shop.php'),

  // Listings
  getListings: (shopId) => request(`/listings/index.php?shop_id=${shopId}`),
  createListing:(body)  => request('/listings/create.php',  { method: 'POST', body }),
  toggleListing:(body)  => request('/listings/toggle.php',  { method: 'POST', body }),

  // Orders
  placeOrder:   (body) => request('/orders/place.php',   { method: 'POST', body }),
  getOrders:    ()     => request('/orders/index.php'),
  advanceOrder: (body) => request('/orders/advance.php', { method: 'POST', body }),

  // Admin
  adminStats:   ()     => request('/admin/stats.php'),
  adminShops:   ()     => request('/admin/shops.php'),
  verifyShop:   (body) => request('/admin/verify_shop.php', { method: 'POST', body }),
};
