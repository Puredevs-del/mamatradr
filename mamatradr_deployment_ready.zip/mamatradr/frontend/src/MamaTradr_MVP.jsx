import { useState, useEffect, useCallback } from "react";
import { api } from "./apiService";

// ─── Helpers ─────────────────────────────────────────────────────────────────
const saveSession = (token, role, user) => {
  localStorage.setItem("mt_token", token);
  localStorage.setItem("mt_role", role);
  localStorage.setItem("mt_user", JSON.stringify(user));
};
const clearSession = () => {
  ["mt_token", "mt_role", "mt_user"].forEach((k) => localStorage.removeItem(k));
};
const getSession = () => ({
  token: localStorage.getItem("mt_token"),
  role:  localStorage.getItem("mt_role"),
  user:  JSON.parse(localStorage.getItem("mt_user") || "null"),
});

const fmt = (n) => `₦${Number(n).toLocaleString("en-NG", { minimumFractionDigits: 2 })}`;

// ─── Toast ────────────────────────────────────────────────────────────────────
function Toast({ msg, type, onDone }) {
  useEffect(() => { const t = setTimeout(onDone, 3500); return () => clearTimeout(t); }, [onDone]);
  const bg = type === "error" ? "#e53e3e" : "#2f855a";
  return (
    <div style={{ position:"fixed", bottom:24, right:24, background:bg, color:"#fff", padding:"12px 20px",
      borderRadius:8, zIndex:9999, maxWidth:320, boxShadow:"0 4px 20px rgba(0,0,0,.3)", fontSize:14 }}>
      {msg}
    </div>
  );
}

// ─── Shared UI ────────────────────────────────────────────────────────────────
const Input = ({ label, ...p }) => (
  <div style={{ marginBottom: 14 }}>
    {label && <label style={{ display:"block", fontSize:12, fontWeight:600, color:"#4a5568", marginBottom:4 }}>{label}</label>}
    <input {...p} style={{ width:"100%", padding:"10px 12px", border:"1.5px solid #e2e8f0",
      borderRadius:7, fontSize:14, outline:"none", boxSizing:"border-box",
      background:"#fff", color:"#1a202c", ...p.style }} />
  </div>
);

const Btn = ({ children, variant = "primary", loading, style, ...p }) => {
  const base = { padding:"10px 18px", borderRadius:7, border:"none", cursor:loading?"wait":"pointer",
    fontSize:14, fontWeight:600, transition:"opacity .15s", opacity: loading ? .6 : 1, ...style };
  const themes = {
    primary:  { background:"#d4a017", color:"#1a202c" },
    success:  { background:"#2f855a", color:"#fff" },
    danger:   { background:"#c53030", color:"#fff" },
    outline:  { background:"transparent", color:"#d4a017", border:"1.5px solid #d4a017" },
    ghost:    { background:"transparent", color:"#718096", border:"1.5px solid #e2e8f0" },
  };
  return <button {...p} style={{ ...base, ...themes[variant] }}>{loading ? "…" : children}</button>;
};

const Card = ({ children, style }) => (
  <div style={{ background:"#fff", borderRadius:10, padding:20, boxShadow:"0 1px 6px rgba(0,0,0,.08)",
    border:"1px solid #f0f0f0", marginBottom:16, ...style }}>
    {children}
  </div>
);

const Badge = ({ label, color = "#2f855a" }) => (
  <span style={{ fontSize:11, fontWeight:700, background:color+"22", color, padding:"3px 8px",
    borderRadius:20, textTransform:"uppercase", letterSpacing:.5 }}>{label}</span>
);

// ─── Auth Forms ───────────────────────────────────────────────────────────────
function AuthPage({ onLogin, showToast }) {
  const [tab, setTab]       = useState("customer_login");
  const [form, setForm]     = useState({});
  const [loading, setLoading] = useState(false);

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const submit = async () => {
    setLoading(true);
    try {
      let data;
      if (tab === "customer_login") {
        data = await api.customerLogin({ email: form.email, password: form.password });
        saveSession(data.token, "customer", data.customer);
        onLogin("customer", data.customer);
      } else if (tab === "customer_reg") {
        data = await api.customerRegister({ name: form.name, email: form.email, phone: form.phone, password: form.password });
        saveSession(data.token, "customer", data.customer);
        onLogin("customer", data.customer);
      } else if (tab === "seller_login") {
        data = await api.sellerLogin({ email: form.email, password: form.password });
        saveSession(data.token, "seller", data.seller);
        onLogin("seller", data.seller);
      } else if (tab === "seller_reg") {
        data = await api.sellerRegister({ name: form.name, email: form.email, phone: form.phone, password: form.password });
        saveSession(data.token, "seller", data.seller);
        onLogin("seller", data.seller);
      } else if (tab === "admin") {
        data = await api.adminLogin({ pin: form.pin });
        saveSession(data.token, "admin", { name: "Admin" });
        onLogin("admin", { name: "Admin" });
      }
      showToast("Welcome to MamaTradr!", "success");
    } catch (err) {
      showToast(err.message, "error");
    } finally {
      setLoading(false);
    }
  };

  const tabs = [
    { id: "customer_login", label: "Customer Login" },
    { id: "customer_reg",   label: "Customer Sign Up" },
    { id: "seller_login",   label: "Seller Login" },
    { id: "seller_reg",     label: "Seller Sign Up" },
    { id: "admin",          label: "Admin" },
  ];

  return (
    <div style={{ minHeight:"100vh", background:"linear-gradient(135deg,#fffbf0 0%,#fff8e1 100%)",
      display:"flex", alignItems:"center", justifyContent:"center", padding:20 }}>
      <div style={{ width:"100%", maxWidth:420 }}>
        {/* Logo */}
        <div style={{ textAlign:"center", marginBottom:28 }}>
          <div style={{ fontSize:38, marginBottom:4 }}>🛒</div>
          <h1 style={{ margin:0, fontSize:28, fontWeight:800, color:"#1a202c" }}>MamaTradr</h1>
          <p style={{ margin:"4px 0 0", color:"#718096", fontSize:14 }}>Your trusted marketplace</p>
        </div>

        {/* Tab pills */}
        <div style={{ display:"flex", gap:6, flexWrap:"wrap", marginBottom:20, justifyContent:"center" }}>
          {tabs.map((t) => (
            <button key={t.id} onClick={() => { setTab(t.id); setForm({}); }}
              style={{ padding:"6px 12px", borderRadius:20, border:"1.5px solid #d4a017", fontSize:12,
                fontWeight:600, cursor:"pointer", background: tab===t.id ? "#d4a017" : "transparent",
                color: tab===t.id ? "#1a202c" : "#d4a017" }}>
              {t.label}
            </button>
          ))}
        </div>

        <Card>
          {(tab === "customer_reg" || tab === "seller_reg") && (
            <Input label="Full Name" placeholder="Ada Obi" value={form.name||""} onChange={set("name")} />
          )}
          {tab !== "admin" && (
            <Input label="Email" type="email" placeholder="you@example.com" value={form.email||""} onChange={set("email")} />
          )}
          {(tab === "customer_reg" || tab === "seller_reg") && (
            <Input label="Phone" placeholder="08012345678" value={form.phone||""} onChange={set("phone")} />
          )}
          {tab !== "admin" && (
            <Input label="Password" type="password" placeholder="••••••••" value={form.password||""} onChange={set("password")} />
          )}
          {tab === "admin" && (
            <Input label="Admin PIN" type="password" placeholder="Enter PIN" value={form.pin||""} onChange={set("pin")} />
          )}
          <Btn onClick={submit} loading={loading} style={{ width:"100%", marginTop:4 }}>
            {tab.includes("reg") ? "Create Account" : "Sign In"}
          </Btn>
        </Card>
      </div>
    </div>
  );
}

// ─── Customer: Marketplace ────────────────────────────────────────────────────
function Marketplace({ user, showToast }) {
  const [shops, setShops]       = useState([]);
  const [active, setActive]     = useState(null); // selected shop
  const [listings, setListings] = useState([]);
  const [cart, setCart]         = useState([]);
  const [orders, setOrders]     = useState([]);
  const [view, setView]         = useState("shops"); // shops | cart | orders
  const [loading, setLoading]   = useState(false);

  useEffect(() => {
    api.getShops().then(setShops).catch(() => {});
    api.getOrders().then(setOrders).catch(() => {});
  }, []);

  const openShop = async (shop) => {
    setActive(shop);
    const data = await api.getListings(shop.id).catch(() => []);
    setListings(data.filter((l) => l.available));
    setView("listings");
  };

  const addToCart = (listing) => {
    setCart((c) => {
      const ex = c.find((i) => i.listing_id === listing.id);
      if (ex) return c.map((i) => i.listing_id === listing.id ? { ...i, qty: i.qty+1 } : i);
      return [...c, { listing_id: listing.id, qty: 1, title: listing.title, price: listing.price, unit: listing.unit }];
    });
    showToast(`${listing.title} added to cart`, "success");
  };

  const removeFromCart = (id) => setCart((c) => c.filter((i) => i.listing_id !== id));

  const placeOrder = async () => {
    if (!cart.length) return;
    setLoading(true);
    try {
      await api.placeOrder({ items: cart.map((i) => ({ listing_id: i.listing_id, qty: i.qty })) });
      setCart([]);
      const fresh = await api.getOrders();
      setOrders(fresh);
      setView("orders");
      showToast("Order placed! Funds held in escrow.", "success");
    } catch (err) {
      showToast(err.message, "error");
    } finally {
      setLoading(false);
    }
  };

  const cartTotal = cart.reduce((s, i) => s + i.price * i.qty, 0);

  const statusColor = { pending:"#d69e2e", confirmed:"#3182ce", shipped:"#805ad5", delivered:"#2f855a", completed:"#276749" };

  return (
    <div>
      {/* Nav */}
      <div style={{ display:"flex", gap:8, marginBottom:20, flexWrap:"wrap" }}>
        <Btn variant={view==="shops"||view==="listings"?"primary":"ghost"} onClick={() => setView("shops")}>🏪 Shops</Btn>
        <Btn variant={view==="cart"?"primary":"ghost"} onClick={() => setView("cart")}>
          🛒 Cart {cart.length > 0 && `(${cart.length})`}
        </Btn>
        <Btn variant={view==="orders"?"primary":"ghost"} onClick={() => setView("orders")}>📦 My Orders</Btn>
      </div>

      {view === "shops" && (
        <div>
          <h3 style={{ margin:"0 0 14px", color:"#2d3748" }}>Verified Shops ({shops.length})</h3>
          {shops.length === 0 && <p style={{ color:"#718096" }}>No shops available yet.</p>}
          {shops.map((s) => (
            <Card key={s.id} style={{ cursor:"pointer" }} onClick={() => openShop(s)}>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start" }}>
                <div>
                  <h4 style={{ margin:"0 0 4px", color:"#1a202c" }}>{s.name}</h4>
                  <p style={{ margin:"0 0 8px", fontSize:13, color:"#718096" }}>{s.description}</p>
                  <Badge label={s.category} color="#3182ce" />
                  {s.location && <span style={{ marginLeft:8, fontSize:12, color:"#a0aec0" }}>📍 {s.location}</span>}
                </div>
                <span style={{ fontSize:12, color:"#718096" }}>{s.listing_count} items →</span>
              </div>
            </Card>
          ))}
        </div>
      )}

      {view === "listings" && active && (
        <div>
          <Btn variant="ghost" onClick={() => setView("shops")} style={{ marginBottom:12 }}>← Back</Btn>
          <h3 style={{ margin:"0 0 14px", color:"#2d3748" }}>{active.name}</h3>
          {listings.length === 0 && <p style={{ color:"#718096" }}>No listings in this shop.</p>}
          {listings.map((l) => (
            <Card key={l.id}>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                <div>
                  <h4 style={{ margin:"0 0 4px", color:"#1a202c" }}>{l.title}</h4>
                  {l.description && <p style={{ margin:"0 0 6px", fontSize:13, color:"#718096" }}>{l.description}</p>}
                  <span style={{ fontWeight:700, color:"#d4a017", fontSize:16 }}>{fmt(l.price)} / {l.unit}</span>
                </div>
                <Btn variant="success" onClick={() => addToCart(l)}>+ Add</Btn>
              </div>
            </Card>
          ))}
        </div>
      )}

      {view === "cart" && (
        <div>
          <h3 style={{ margin:"0 0 14px", color:"#2d3748" }}>Your Cart</h3>
          {cart.length === 0 && <p style={{ color:"#718096" }}>Cart is empty.</p>}
          {cart.map((i) => (
            <Card key={i.listing_id}>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                <div>
                  <strong>{i.title}</strong>
                  <div style={{ fontSize:13, color:"#718096", marginTop:2 }}>
                    {fmt(i.price)} × {i.qty} = <strong>{fmt(i.price * i.qty)}</strong>
                  </div>
                </div>
                <div style={{ display:"flex", gap:6, alignItems:"center" }}>
                  <Btn variant="ghost" style={{ padding:"4px 10px" }}
                    onClick={() => setCart((c) => c.map((x) => x.listing_id===i.listing_id ? {...x, qty: Math.max(1,x.qty-1)} : x))}>−</Btn>
                  <span style={{ fontSize:14, fontWeight:600 }}>{i.qty}</span>
                  <Btn variant="ghost" style={{ padding:"4px 10px" }}
                    onClick={() => setCart((c) => c.map((x) => x.listing_id===i.listing_id ? {...x, qty: x.qty+1} : x))}>+</Btn>
                  <Btn variant="danger" style={{ padding:"4px 10px" }} onClick={() => removeFromCart(i.listing_id)}>✕</Btn>
                </div>
              </div>
            </Card>
          ))}
          {cart.length > 0 && (
            <Card style={{ background:"#fffbf0", border:"1.5px solid #d4a017" }}>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                <span style={{ fontWeight:700, fontSize:16 }}>Total: {fmt(cartTotal)}</span>
                <Btn variant="primary" loading={loading} onClick={placeOrder}>Place Order & Hold Escrow</Btn>
              </div>
            </Card>
          )}
        </div>
      )}

      {view === "orders" && (
        <div>
          <h3 style={{ margin:"0 0 14px", color:"#2d3748" }}>My Orders ({orders.length})</h3>
          {orders.length === 0 && <p style={{ color:"#718096" }}>No orders yet.</p>}
          {orders.map((o) => (
            <Card key={o.id}>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:6 }}>
                <strong style={{ fontSize:15 }}>Order #{o.id}</strong>
                <Badge label={o.status} color={statusColor[o.status] || "#718096"} />
              </div>
              <p style={{ margin:"0 0 4px", fontSize:13, color:"#718096" }}>{o.items_summary}</p>
              <span style={{ fontWeight:700, color:"#d4a017" }}>{fmt(o.total_amount)}</span>
              <span style={{ marginLeft:12, fontSize:12, color:"#a0aec0" }}>{new Date(o.created_at).toLocaleDateString()}</span>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── Seller Dashboard ─────────────────────────────────────────────────────────
function SellerDashboard({ user, showToast }) {
  const [shop, setShop]         = useState(null);
  const [listings, setListings] = useState([]);
  const [orders, setOrders]     = useState([]);
  const [view, setView]         = useState("shop");
  const [form, setForm]         = useState({});
  const [loading, setLoading]   = useState(false);

  const refresh = useCallback(async () => {
    try {
      const s = await api.myShop();
      setShop(s);
      const l = await api.getListings(s.id);
      setListings(l);
    } catch {}
    try { setOrders(await api.getOrders()); } catch {}
  }, []);

  useEffect(() => { refresh(); }, [refresh]);

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const createShop = async () => {
    if (!form.name || !form.description || !form.category) {
      return showToast("Name, description and category are required", "error");
    }
    setLoading(true);
    try {
      await api.createShop({ name: form.name, description: form.description, category: form.category, location: form.location });
      showToast("Shop created! Awaiting admin verification.", "success");
      setForm({});
      refresh();
    } catch (err) { showToast(err.message, "error"); }
    finally { setLoading(false); }
  };

  const addListing = async () => {
    if (!form.title || !form.price) return showToast("Title and price required", "error");
    setLoading(true);
    try {
      await api.createListing({ title: form.title, description: form.ldesc, price: form.price, stock: form.stock || 0, unit: form.unit || "item" });
      showToast("Listing added!", "success");
      setForm({});
      refresh();
    } catch (err) { showToast(err.message, "error"); }
    finally { setLoading(false); }
  };

  const toggle = async (id) => {
    try {
      await api.toggleListing({ listing_id: id });
      refresh();
    } catch (err) { showToast(err.message, "error"); }
  };

  const advance = async (orderId) => {
    try {
      const data = await api.advanceOrder({ order_id: orderId });
      showToast(`Order moved to: ${data.status}`, "success");
      refresh();
    } catch (err) { showToast(err.message, "error"); }
  };

  const statusColor = { pending:"#d69e2e", confirmed:"#3182ce", shipped:"#805ad5", delivered:"#2f855a", completed:"#276749" };

  return (
    <div>
      <div style={{ display:"flex", gap:8, marginBottom:20, flexWrap:"wrap" }}>
        <Btn variant={view==="shop"?"primary":"ghost"} onClick={() => setView("shop")}>🏪 My Shop</Btn>
        <Btn variant={view==="listings"?"primary":"ghost"} onClick={() => setView("listings")}>📋 Listings</Btn>
        <Btn variant={view==="orders"?"primary":"ghost"} onClick={() => setView("orders")}>📦 Orders</Btn>
      </div>

      {view === "shop" && (
        <div>
          {!shop ? (
            <Card>
              <h3 style={{ margin:"0 0 16px", color:"#2d3748" }}>Create Your Shop</h3>
              <Input label="Shop Name" placeholder="Ada's Fresh Produce" value={form.name||""} onChange={set("name")} />
              <Input label="Description" placeholder="Farm-fresh vegetables and fruits" value={form.description||""} onChange={set("description")} />
              <Input label="Category" placeholder="Food & Grocery" value={form.category||""} onChange={set("category")} />
              <Input label="Location (optional)" placeholder="Lagos, Yaba Market" value={form.location||""} onChange={set("location")} />
              <Btn loading={loading} onClick={createShop}>Create Shop</Btn>
            </Card>
          ) : (
            <Card>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:10 }}>
                <h3 style={{ margin:0, color:"#2d3748" }}>{shop.name}</h3>
                <Badge label={shop.verified ? "Verified" : "Pending"} color={shop.verified ? "#2f855a" : "#d69e2e"} />
              </div>
              <p style={{ margin:"0 0 6px", color:"#718096", fontSize:14 }}>{shop.description}</p>
              <Badge label={shop.category} color="#3182ce" />
              {shop.location && <span style={{ marginLeft:8, fontSize:13, color:"#a0aec0" }}>📍 {shop.location}</span>}
              <div style={{ marginTop:12, padding:"10px 14px", background:"#f7fafc", borderRadius:7, fontSize:13, color:"#4a5568" }}>
                📊 {shop.listing_count} listing{shop.listing_count !== 1 ? "s" : ""} · {orders.length} order{orders.length !== 1 ? "s" : ""}
              </div>
              {!shop.verified && (
                <div style={{ marginTop:10, padding:"10px 14px", background:"#fffbeb", borderRadius:7, fontSize:13, color:"#744210", border:"1px solid #f6e05e" }}>
                  ⏳ Your shop is awaiting admin verification before appearing in the marketplace.
                </div>
              )}
            </Card>
          )}
        </div>
      )}

      {view === "listings" && (
        <div>
          {shop && (
            <Card style={{ background:"#fffbf0", border:"1.5px solid #d4a017" }}>
              <h4 style={{ margin:"0 0 12px", color:"#2d3748" }}>Add New Listing</h4>
              <Input label="Product Title" placeholder="Fresh Tomatoes" value={form.title||""} onChange={set("title")} />
              <Input label="Description" placeholder="Locally grown, Grade A" value={form.ldesc||""} onChange={set("ldesc")} />
              <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:10 }}>
                <Input label="Price (₦)" type="number" placeholder="500" value={form.price||""} onChange={set("price")} />
                <Input label="Stock" type="number" placeholder="50" value={form.stock||""} onChange={set("stock")} />
                <Input label="Unit" placeholder="kg / item / bag" value={form.unit||""} onChange={set("unit")} />
              </div>
              <Btn loading={loading} onClick={addListing}>Add Listing</Btn>
            </Card>
          )}

          <h3 style={{ margin:"0 0 14px", color:"#2d3748" }}>Your Listings ({listings.length})</h3>
          {listings.length === 0 && <p style={{ color:"#718096" }}>No listings yet.</p>}
          {listings.map((l) => (
            <Card key={l.id}>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                <div>
                  <h4 style={{ margin:"0 0 4px", color:"#1a202c" }}>{l.title}</h4>
                  <span style={{ fontWeight:700, color:"#d4a017" }}>{fmt(l.price)} / {l.unit}</span>
                  <span style={{ marginLeft:10, fontSize:12, color:"#a0aec0" }}>Stock: {l.stock}</span>
                </div>
                <div style={{ display:"flex", gap:8, alignItems:"center" }}>
                  <Badge label={l.available ? "Active" : "Hidden"} color={l.available ? "#2f855a" : "#718096"} />
                  <Btn variant={l.available ? "outline" : "success"} style={{ padding:"5px 12px", fontSize:12 }}
                    onClick={() => toggle(l.id)}>
                    {l.available ? "Hide" : "Show"}
                  </Btn>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      {view === "orders" && (
        <div>
          <h3 style={{ margin:"0 0 14px", color:"#2d3748" }}>Orders ({orders.length})</h3>
          {orders.length === 0 && <p style={{ color:"#718096" }}>No orders yet.</p>}
          {orders.map((o) => (
            <Card key={o.id}>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:6 }}>
                <strong>Order #{o.id}</strong>
                <Badge label={o.status} color={statusColor[o.status] || "#718096"} />
              </div>
              <p style={{ margin:"0 0 4px", fontSize:13, color:"#718096" }}>{o.items_summary}</p>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                <span style={{ fontWeight:700, color:"#d4a017" }}>{fmt(o.total_amount)}</span>
                {!["delivered","completed"].includes(o.status) && (
                  <Btn variant="success" style={{ padding:"5px 14px", fontSize:12 }} onClick={() => advance(o.id)}>
                    Advance →
                  </Btn>
                )}
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── Admin Panel ──────────────────────────────────────────────────────────────
function AdminPanel({ showToast }) {
  const [stats, setStats]   = useState(null);
  const [shops, setShops]   = useState([]);
  const [orders, setOrders] = useState([]);
  const [view, setView]     = useState("stats");

  const refresh = useCallback(async () => {
    try { setStats(await api.adminStats()); } catch {}
    try { setShops(await api.adminShops()); } catch {}
    try { setOrders(await api.getOrders()); } catch {}
  }, []);

  useEffect(() => { refresh(); }, [refresh]);

  const verify = async (id) => {
    try {
      await api.verifyShop({ shop_id: id });
      showToast("Shop verified!", "success");
      refresh();
    } catch (err) { showToast(err.message, "error"); }
  };

  const advance = async (id) => {
    try {
      const data = await api.advanceOrder({ order_id: id });
      showToast(`Order → ${data.status}`, "success");
      refresh();
    } catch (err) { showToast(err.message, "error"); }
  };

  const StatBox = ({ label, value, color = "#1a202c" }) => (
    <div style={{ background:"#fff", borderRadius:10, padding:"16px 18px", boxShadow:"0 1px 6px rgba(0,0,0,.08)",
      border:"1px solid #f0f0f0", flex:1, minWidth:130 }}>
      <div style={{ fontSize:22, fontWeight:800, color }}>{value ?? "…"}</div>
      <div style={{ fontSize:12, color:"#718096", marginTop:2 }}>{label}</div>
    </div>
  );

  const statusColor = { pending:"#d69e2e", confirmed:"#3182ce", shipped:"#805ad5", delivered:"#2f855a", completed:"#276749" };

  return (
    <div>
      <div style={{ display:"flex", gap:8, marginBottom:20, flexWrap:"wrap" }}>
        <Btn variant={view==="stats"?"primary":"ghost"} onClick={() => setView("stats")}>📊 Stats</Btn>
        <Btn variant={view==="shops"?"primary":"ghost"} onClick={() => setView("shops")}>🏪 Shops</Btn>
        <Btn variant={view==="orders"?"primary":"ghost"} onClick={() => setView("orders")}>📦 Orders</Btn>
      </div>

      {view === "stats" && stats && (
        <div>
          <h3 style={{ margin:"0 0 14px", color:"#2d3748" }}>Platform Overview</h3>
          <div style={{ display:"flex", gap:12, flexWrap:"wrap", marginBottom:16 }}>
            <StatBox label="Sellers" value={stats.sellers} color="#d4a017" />
            <StatBox label="Customers" value={stats.customers} color="#3182ce" />
            <StatBox label="Total Shops" value={stats.shops_total} />
            <StatBox label="Pending Shops" value={stats.shops_pending} color="#e53e3e" />
          </div>
          <div style={{ display:"flex", gap:12, flexWrap:"wrap" }}>
            <StatBox label="Total Orders" value={stats.orders_total} />
            <StatBox label="Pending Orders" value={stats.orders_pending} color="#d69e2e" />
            <StatBox label="Escrow Held" value={fmt(stats.revenue_held)} color="#805ad5" />
            <StatBox label="Released" value={fmt(stats.revenue_released)} color="#2f855a" />
          </div>
        </div>
      )}

      {view === "shops" && (
        <div>
          <h3 style={{ margin:"0 0 14px", color:"#2d3748" }}>All Shops ({shops.length})</h3>
          {shops.map((s) => (
            <Card key={s.id}>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start" }}>
                <div>
                  <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:4 }}>
                    <strong>{s.name}</strong>
                    <Badge label={s.verified ? "Verified" : "Pending"} color={s.verified ? "#2f855a" : "#d69e2e"} />
                  </div>
                  <div style={{ fontSize:13, color:"#718096" }}>{s.seller_name} · {s.seller_email}</div>
                  <div style={{ fontSize:12, color:"#a0aec0", marginTop:2 }}>{s.listing_count} listings · {s.category}</div>
                </div>
                {!s.verified && (
                  <Btn variant="success" style={{ padding:"6px 14px", fontSize:12 }} onClick={() => verify(s.id)}>
                    ✓ Verify
                  </Btn>
                )}
              </div>
            </Card>
          ))}
        </div>
      )}

      {view === "orders" && (
        <div>
          <h3 style={{ margin:"0 0 14px", color:"#2d3748" }}>All Orders ({orders.length})</h3>
          {orders.map((o) => (
            <Card key={o.id}>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:6 }}>
                <div>
                  <strong>Order #{o.id}</strong>
                  {o.customer_name && <span style={{ marginLeft:8, fontSize:13, color:"#718096" }}>by {o.customer_name}</span>}
                </div>
                <Badge label={o.status} color={statusColor[o.status] || "#718096"} />
              </div>
              <p style={{ margin:"0 0 4px", fontSize:13, color:"#718096" }}>{o.items_summary}</p>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                <span style={{ fontWeight:700, color:"#d4a017" }}>{fmt(o.total_amount)}</span>
                {!["completed"].includes(o.status) && (
                  <Btn variant="outline" style={{ padding:"5px 14px", fontSize:12 }} onClick={() => advance(o.id)}>
                    Advance →
                  </Btn>
                )}
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── App Shell ────────────────────────────────────────────────────────────────
export default function App() {
  const [session, setSession] = useState(getSession);
  const [toast, setToast]     = useState(null);

  const showToast = useCallback((msg, type = "success") => {
    setToast({ msg, type, key: Date.now() });
  }, []);

  const onLogin = (role, user) => setSession({ token: localStorage.getItem("mt_token"), role, user });

  const logout = () => {
    clearSession();
    setSession({ token: null, role: null, user: null });
    showToast("Logged out", "success");
  };

  const { role, user } = session;

  const roleBadgeColor = { seller: "#805ad5", customer: "#3182ce", admin: "#e53e3e" };

  return (
    <div style={{ minHeight:"100vh", background:"#f7fafc", fontFamily:"'Segoe UI', system-ui, sans-serif" }}>
      {/* Header */}
      {role && (
        <header style={{ background:"#1a202c", color:"#fff", padding:"0 20px",
          display:"flex", alignItems:"center", justifyContent:"space-between", height:56, position:"sticky", top:0, zIndex:100 }}>
          <div style={{ display:"flex", alignItems:"center", gap:10 }}>
            <span style={{ fontSize:22 }}>🛒</span>
            <span style={{ fontWeight:800, fontSize:18, letterSpacing:"-0.5px" }}>MamaTradr</span>
          </div>
          <div style={{ display:"flex", alignItems:"center", gap:12 }}>
            <span style={{ fontSize:13, color:"#a0aec0" }}>
              {user?.name} · <span style={{ color: roleBadgeColor[role] || "#d4a017", fontWeight:700, textTransform:"capitalize" }}>{role}</span>
            </span>
            <Btn variant="danger" style={{ padding:"5px 12px", fontSize:12 }} onClick={logout}>Logout</Btn>
          </div>
        </header>
      )}

      {/* Body */}
      <main style={{ maxWidth:720, margin:"0 auto", padding: role ? "20px 16px" : 0 }}>
        {!role && <AuthPage onLogin={onLogin} showToast={showToast} />}
        {role === "customer" && <Marketplace user={user} showToast={showToast} />}
        {role === "seller"   && <SellerDashboard user={user} showToast={showToast} />}
        {role === "admin"    && <AdminPanel showToast={showToast} />}
      </main>

      {toast && <Toast key={toast.key} msg={toast.msg} type={toast.type} onDone={() => setToast(null)} />}
    </div>
  );
}
